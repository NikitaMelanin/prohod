﻿using Prohod.Domain.ErrorsBase;

namespace Prohod.Domain.Users.Errors;

// Marker interface
public interface IApplyFormError : IOperationError
{ }