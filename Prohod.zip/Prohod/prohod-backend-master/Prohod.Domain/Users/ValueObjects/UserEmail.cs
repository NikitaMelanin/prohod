﻿namespace Prohod.Domain.Users;

public record UserEmail(string Value);