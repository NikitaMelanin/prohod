namespace Prohod.Domain.Users;

public record Name(string Value);