﻿namespace Prohod.Domain.Users;

public record UserId(Guid Value);