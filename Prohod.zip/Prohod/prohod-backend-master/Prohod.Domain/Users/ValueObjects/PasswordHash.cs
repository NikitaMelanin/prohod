namespace Prohod.Domain.Users;

public record PasswordHash(string Value);