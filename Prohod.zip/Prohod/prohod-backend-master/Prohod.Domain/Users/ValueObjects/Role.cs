﻿namespace Prohod.Domain.Users;

public enum Role
{
    User = 1,
    Security = 2,
    Admin = 3,
}