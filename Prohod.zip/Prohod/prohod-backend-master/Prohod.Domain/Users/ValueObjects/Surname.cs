namespace Prohod.Domain.Users;

public record Surname(string Value);