namespace Prohod.Domain.Users;

public record Login(string Value);