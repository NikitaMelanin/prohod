namespace Prohod.Domain.VisitRequests.Forms;

public record FormId(Guid Value);