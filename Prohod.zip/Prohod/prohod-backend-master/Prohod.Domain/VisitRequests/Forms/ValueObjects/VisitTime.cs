namespace Prohod.Domain.VisitRequests.Forms;

public record VisitTime(DateTimeOffset Value);