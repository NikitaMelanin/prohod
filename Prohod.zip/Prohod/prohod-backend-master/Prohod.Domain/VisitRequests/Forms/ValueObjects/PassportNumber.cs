namespace Prohod.Domain.VisitRequests.Forms;

public record PassportNumber(string Value);