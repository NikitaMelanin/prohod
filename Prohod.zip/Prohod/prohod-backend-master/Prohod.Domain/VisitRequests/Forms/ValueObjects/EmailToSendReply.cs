﻿namespace Prohod.Domain.VisitRequests.Forms;

public record EmailToSendReply(string Value);