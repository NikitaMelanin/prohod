namespace Prohod.Domain.VisitRequests.Forms;

public record VisitReason(string Value);