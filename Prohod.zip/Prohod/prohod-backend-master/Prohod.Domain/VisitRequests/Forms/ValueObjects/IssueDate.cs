namespace Prohod.Domain.VisitRequests.Forms;

public record IssueDate(DateTimeOffset Value);