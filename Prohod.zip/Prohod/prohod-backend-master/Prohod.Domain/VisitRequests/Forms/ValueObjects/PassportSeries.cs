namespace Prohod.Domain.VisitRequests.Forms;

public record PassportSeries(string Value);