namespace Prohod.Domain.VisitRequests.Forms;

public record FullName(string Value);