namespace Prohod.Domain.VisitRequests.Forms;

public record WhoIssued(string Value);