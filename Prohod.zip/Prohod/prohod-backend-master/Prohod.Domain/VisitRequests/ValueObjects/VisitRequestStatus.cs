﻿namespace Prohod.Domain.VisitRequests;

public enum VisitRequestStatus
{
    NotProcessed = 1,
    Reject = 2,
    Accept = 3,
}