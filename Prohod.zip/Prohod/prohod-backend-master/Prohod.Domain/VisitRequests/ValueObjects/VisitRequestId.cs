namespace Prohod.Domain.VisitRequests;

public record VisitRequestId(Guid Value);