namespace Prohod.Domain.VisitRequests;

public record RejectionReason(string Value);