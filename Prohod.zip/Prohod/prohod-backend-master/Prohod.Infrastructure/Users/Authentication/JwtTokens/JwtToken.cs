﻿namespace Prohod.Infrastructure.Users.Authentication.JwtTokens;

public record JwtToken(string Value);