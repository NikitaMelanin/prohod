﻿namespace Prohod.WebApi.Users.Authentication.Models;

public record LoginRequest(string Login, string Password);
