using Prohod.WebApi.VisitRequests.Models.Forms;

namespace Prohod.WebApi.VisitRequests.Models.ApplyForm;

public record ApplyFormRequest(FormDto Form);