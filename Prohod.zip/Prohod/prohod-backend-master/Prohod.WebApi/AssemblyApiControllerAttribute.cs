﻿using Microsoft.AspNetCore.Mvc;

[assembly: ApiController]